# bluehost setup
- pull any changes from github
- create empty database, with new team names (sql for this is up a directory)
- servername is localhost
- input new db name, username and password
