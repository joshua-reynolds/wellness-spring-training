<?php

$dbServername = "localhost";
$dbUsername = "wfrcorg_wellness";
$dbPassword = 'spring2023';
$dbName = 'wfrcorg_wellness_spring_training_3'; // change this to new db every week

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);

?>