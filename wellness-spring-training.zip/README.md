# wellness-spring-training

A baseball-themed web application developed for the WFRC wellness team using PHP and mySQL

![alt text](graphics/mobile-screenshot-new.PNG)